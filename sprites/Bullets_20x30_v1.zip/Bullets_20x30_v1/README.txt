This asset pack contains 14 bullet sprites which is of size 20x30, 
and for bullet-4, there is a longer version (size 20x40) of it.

Besides, a ship sprite is also shipped within this pack.
----
Enjoy!

Sky
